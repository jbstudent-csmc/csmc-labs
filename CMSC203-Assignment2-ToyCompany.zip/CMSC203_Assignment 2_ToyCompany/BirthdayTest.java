package toyCompany;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BirthdayTest {
Toy t;

	
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	void testSetToy()
	{
		assertEquals(t.setToy(String t);
	}
	
	@Test
	void testAddCard()
	{
		assertEquals(t.addCard(s); "yes");
	}
	
	//public void test() {
		//fail("Not yet implemented");
	//}
	

}
