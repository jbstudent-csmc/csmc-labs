package toyCompany;
import java.util.Scanner;
import java.util.Random;

import toyCompany.Toy;

/** CMSC 203 Spring 2020
* @author Jon Howard
* Professor: Eivazi
*
*/
public class Birthday {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner keyboard = new Scanner(System.in);
	    String name;
		int age;
		Toy myToy = new Toy();
		String gifts;
		String response;
		char answer;
		Random rand = new Random();
		int productNumber = 1000 + rand.nextInt(10000-1000);
		
		
		System.out.println("Welcome to the toy company, to assist in finding gifts for young children");
		//Stating the function of the program itself.
		
		do
		{
		System.out.println("Please enter the name of the child."); //Output to screen the name
		name = keyboard.toString();                                //Taking input from the user and setting it to name
		//myToy.setName(name);                                       //Taking name and calling it to the function setName
		keyboard.nextLine();
		
		System.out.println("How old is the child?");              //Output to screen for the age of the child.
		age = keyboard.nextInt();                                  // Taking input from the user and inputting into age.
		 myToy.setAge(age);                                        // Putting age into setAge
		 
		System.out.println("Choose a toy: plushie blocks or a book"); //Output to tell the user to pick a toy.
		System.out.println("\nPlushie for age 2 and under, blocks from 3-5 and books 4-7");
		gifts = keyboard.next();                                      // The next input from the user is called gifts.
		
		
		if(!gifts.equals("plushie") && !gifts.equals("blocks") && !gifts.equals("book")) //Error checking  to see if it equals a string of plushie blocks or books.
		{
			System.out.println("Invalid choice.");
			System.out.println("Please enter plushie, blocks or book");
			gifts = keyboard.next();
		}
		
		
		myToy.setCost(gifts);                             //Setting gifts to setToy in myToy.
		
		
		myToy.ageOK();                                   //Calling to ageOk.
		
		
		//if (myToy.ageOK() == false);                  // Error checking if the age is true or false.
		//{
		//System.out.println("This toy is not age appropriate. Do you want to buy a different toy?");
		
		//myToy.setCost(gifts);
		//}
		System.out.println("Do you want a card with the gift? Yes or No"); //Prompting the user if they want to add a gift card.
		response = keyboard.next();                                        //Response from user is set as "response"
		myToy.addCard(response);                                           //Passing response to addCard.
		
		System.out.println("Do you want a balloon with the gift? Yes or No");  //Prompting the user if the wants a balloon.
		response = keyboard.next();                                           //Response from the user is set as "response".
		myToy.addBalloon(response);                                           //Passing response to addBalloon.
		
		System.out.println(myToy.toString());                                 //Printing out the toString object in myToy.
		
		System.out.println("Do you want to enter another gift?");             //Prompt the user if they want to enter another gift
		answer = keyboard.next().charAt(0);  //Reading the first value if Y or y.
		keyboard.nextLine(); 
		}
		while((answer == 'y' || answer == 'Y'));                             //If answer is "Y" or "y" loop back to the beginning.
		
		System.out.println("Product Number: " + productNumber );             //Output product name by calling product number setting a random number.
		System.out.println("Programmer Jon Howard.");                        // Programmer name.
	}

}
