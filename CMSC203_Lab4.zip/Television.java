/**
 * 
 * @author Jon Howard
 * Professor: Eivazi
 * Lab 4
 * CMSC203
 * 3/8/2020
 *
 */
public class Television {

	private String MANUFACTURER;
	private int SCREEN_SIZE;
	private int channel;
	private int volume;
	private boolean powerOn;
	
	/**
	 * 
	 * @param brand
	 * @param size
	 */
	public Television( String brand , int size)
	{
		this.MANUFACTURER = brand;
		this.SCREEN_SIZE = size;
		powerOn = false;
		volume = 20;
		channel = 2;
	}
	/**
	 * 
	 * @param station
	 */
	public  void setChannel ( int station)
	{
		channel = station;
	}
	/**
	 * Sets the power to ON or OFF.
	 */
	public  void power()
	{
		 powerOn = !powerOn; 
	}
	/**
	 * Increases volume by 1.
	 */
	public  void increaseVolume()
	{
		volume +=1;
	}
	/**
	 * Decreases volume by 1.
	 */
	public  void decreaseVolume()
	{
		volume -=1;
	}
	/**
	 * 
	 * @return channel
	 */
	public  int getChannel()
	{
		return channel;
	}
	/**
	 * 
	 * @return volume
	 */
	public int getVolume()
	{
		return volume;
	}
	/**
	 * 
	 * @return MANUFACTURER
	 */
	public String getManufacturer()
	{
		return MANUFACTURER;
	}
	
	/**
	 * 
	 * @return SCREEN_SIZE
	 */
	public int getScreenSize()
	{
		return SCREEN_SIZE;
	}
}
	

